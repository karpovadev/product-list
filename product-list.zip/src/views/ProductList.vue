<template>
  <div class="home">
    <div class="products-wrapper">
      <product-item
        v-for="product in countProducts"
        :key="product._id"
        :product="product"
      ></product-item>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import ProductItem from "@/components/ProductItem.vue";
import data from "@/data/products.json";

export default {
  name: "ProductList",
  components: {
    ProductItem,
  },
  data() {
    return {
      products: data,
    };
  },
  computed: {
    countProducts: function() {
      return this.products.slice(0, 9);
    },
  },
  methods: {
    // getPosts() {
    //   fetch("data/products.json");
    //   fetch("https://jsonplaceholder.typicode.com/todos")
    //     .then((response) => response.json())
    //     .then((json) => console.log(json))
    //     .catch((error) => console.log(error));
    // },
  },
  mounted() {
    // this.getPosts();
  },
};
</script>
