<template>
  <div class="product-item">
    <div class="inner">
      <div class="favourite-icon">❤️</div>
      <div class="thumbnail">
        <img src="" alt="" />
      </div>
      <div class="info">
        <h5 class="item-title">{{ product.name }}</h5>
        <div class="product-size">
          {{ product.size }}
          <span class="product-rating">{{ product.rating }}</span>
        </div>
        <div class="product-price">
          <span class="price">{{ product.price }}</span>
          <span class="old-price">{{ product.oldPrice }} </span>
          <span class="savings">You save {{ product.savings }} </span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "ProductItem",
  props: ["product"],
};
</script>

<style lang="less">
.products-wrapper {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
}
.product {
  &-item {
    width: 30%;
  }
}
</style>
